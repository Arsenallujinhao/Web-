<template>
	<div>
		品牌营销
	</div>
</template>
<script>
	
export default{
	name:"loud",
	data(){
		return{

		}
	}
}	

</script>
<style>
	
</style>