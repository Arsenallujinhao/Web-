<template>
	<div class="app-foot">
		<p>品类齐全，轻松购物快 多仓直发，极速配送好 正品行货，精致服务省 天天低价，畅选无忧</p>
	</div>
</template>
<script>
	
export default{
	name:"footers",
	data(){
		return{

		}
	}
}	

</script>
<style scoped>
.app-foot {
	text-align: center;
	height: 80px;
	width: 100%;
	line-height: 80px;
	background: #e3e4e8;
	clear: both;
	margin-top: 30px;
}
.app-foot p{
	display: inline-block;
}	
</style>